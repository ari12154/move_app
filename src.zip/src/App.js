// import logo from './logo.svg';
import './App.css';
import SignIn from './comps/sign/SignIn';
import Movie from './movie';

function App() {
  return (
    <div className="App">
      <Movie/>
    </div>
  );
}

export default App;
